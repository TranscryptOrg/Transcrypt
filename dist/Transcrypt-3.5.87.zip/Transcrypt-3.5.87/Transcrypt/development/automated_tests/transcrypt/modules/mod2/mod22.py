class B:
	def __init__ (self):
		self.x = 'Geef mij maar Amsterdam\n'
		