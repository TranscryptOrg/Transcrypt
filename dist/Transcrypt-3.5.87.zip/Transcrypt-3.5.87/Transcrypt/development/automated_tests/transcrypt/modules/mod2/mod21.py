def f ():
	return 'London is the town for me\n'
	