x = 'Toen wij uit Rotterdam vertrokken, vertrokken wij uit Rotterdam\n'
mod3Hundred = 100

def mod3GetTwoHundred ():
	return 200
	