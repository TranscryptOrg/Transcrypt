def run (autoTester):
	autoTester.check ('hello')
	autoTester.check ('world')
