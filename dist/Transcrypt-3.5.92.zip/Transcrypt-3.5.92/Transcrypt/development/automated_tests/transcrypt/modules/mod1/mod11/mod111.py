class A:
	def __init__ (self, x):
		self.x = x
		
	def f (self):
		return self.x
		