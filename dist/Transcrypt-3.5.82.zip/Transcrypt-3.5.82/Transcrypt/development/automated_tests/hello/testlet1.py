def run (autoTester):
	autoTester.check ('goodbye')
	autoTester.check ('moon')
