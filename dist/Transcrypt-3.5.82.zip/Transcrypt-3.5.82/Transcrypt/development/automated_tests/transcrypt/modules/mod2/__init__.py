def f (p):
	return 2 * p
	