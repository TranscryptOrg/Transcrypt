def f ():
	return ('Paris, c\'est la vie\n')
	