	__nest__ (
		__all__,
		'\', {
			__all__: {
				__inited__: false,
				__init__: function (__all__) {
				}
			}
		}
	);
